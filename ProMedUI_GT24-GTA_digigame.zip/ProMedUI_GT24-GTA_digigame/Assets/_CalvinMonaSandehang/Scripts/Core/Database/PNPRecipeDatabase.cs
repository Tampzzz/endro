using _CalvinMonaSandehang.ItemSystem;
using Sirenix.OdinInspector;
using System.Collections.Generic;
using UnityEngine;
using static _CalvinMonaSandehang.GlobalDefine;

namespace _CalvinMonaSandehang.Database
{
    public class PNPRecipeDatabase : MonoBehaviour
    {
        [SerializeField]
        private List<PNPMaterialRecipe> _recipeDatabase;

        [ShowInInspector]
        public Dictionary<(MaterialModel, MaterialModel), MaterialModel> PNPRecipe = new ();

        // Singleton pattern
        public static PNPRecipeDatabase Instance;

        private void Awake()
        {
            if (Instance == null)
                Instance = this;
            else
                Destroy(gameObject);

            foreach (var recipe in _recipeDatabase)
            {
                AddRecipe(recipe.Material1.CreateMaterialModel(), 
                    recipe.Material2.CreateMaterialModel(), recipe.Product.CreateMaterialModel());
            }
        }

        // Add a recipe to the database
        public void AddRecipe(MaterialModel material1, MaterialModel material2, MaterialModel product)
        {
            PNPRecipe[(material1, material2)] = product;
        }

        // Remove a recipe from the database
        public void RemoveRecipe(MaterialModel material1, MaterialModel material2)
        {
            PNPRecipe.Remove((material1, material2));
        }

        // Get a product for a given pair of materials, considering interchangeability
        public MaterialModel GetProduct(MaterialModel material1, MaterialModel material2)
        {
            MaterialModel product;
            if (PNPRecipe.TryGetValue((material1, material2), out product))
            {
                return product;
            }
            else if (PNPRecipe.TryGetValue((material2, material1), out product))
            {
                return product;
            }
            else
            {
                return null;
            }
        }


        // Check if a recipe exists for a given pair of materials
        public bool RecipeExists(MaterialModel material1, MaterialModel material2)
        {
            return PNPRecipe.ContainsKey((material1, material2)) || PNPRecipe.ContainsKey((material2, material1));
        }
    }
}
