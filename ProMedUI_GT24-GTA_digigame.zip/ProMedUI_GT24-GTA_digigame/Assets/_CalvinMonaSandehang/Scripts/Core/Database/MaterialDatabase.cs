using _CalvinMonaSandehang.ItemSystem;
using Sirenix.OdinInspector;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace _CalvinMonaSandehang.Database 
{
    public class MaterialDatabase : MonoBehaviour
    {
        [SerializeField]
        private List<MaterialSO> _materials = new List<MaterialSO>();

        [ShowInInspector]
        public Dictionary<string, MaterialModel> MaterialDatabaseDict = new Dictionary<string, MaterialModel>();


        private void Awake()
        {
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            foreach (MaterialSO material in _materials)
            {
                MaterialModel materialModel = new MaterialModel(material);
                MaterialDatabaseDict.Add(material.ID, materialModel);
            }
        }

        public MaterialModel GetMaterial(string id)
        {

            if (MaterialDatabaseDict.ContainsKey(id))
            {
                return MaterialDatabaseDict[id];
            }
            else
            {
                Debug.LogError("Material with ID " + id + " does not exist in the database.");
                return null;
            }
        }
    }
}

