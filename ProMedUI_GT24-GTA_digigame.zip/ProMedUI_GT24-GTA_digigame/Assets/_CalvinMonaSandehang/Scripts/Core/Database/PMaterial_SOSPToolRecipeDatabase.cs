using System;
using System.Collections.Generic;
using UnityEngine;
using _CalvinMonaSandehang.ItemSystem;
using static _CalvinMonaSandehang.GlobalDefine;

namespace _CalvinMonaSandehang.Database
{
    public class PMaterial_SOSPToolRecipeDatabase : MonoBehaviour
    {
        [SerializeField]
        private List<PMaterialToolRecipe> _recipeDatabase;

        public Dictionary<(string, string), MaterialModel> RecipeDictionary = new ();

        // Singleton pattern
        public static PMaterial_SOSPToolRecipeDatabase Instance { get; private set; }

        private void Awake()
        {
            if (Instance == null)
                Instance = this;
            else
                Destroy(gameObject);

            InitializeRecipeDatabase();
        }

        private void InitializeRecipeDatabase()
        {
            foreach (var recipe in _recipeDatabase)
            {
                AddRecipe(recipe.Material.ID, recipe.Tool.ID, recipe.Product.CreateMaterialModel());
            }
        }

        // Add a recipe to the database
        public void AddRecipe(string materialID, string toolID, MaterialModel product)
        {
            RecipeDictionary[(materialID, toolID)] = product;
        }

        // Remove a recipe from the database
        public void RemoveRecipe(string materialID, string toolID)
        {
            RecipeDictionary.Remove((materialID, toolID));
        }

        // Get a product for a given material and tool
        public MaterialModel GetProduct(string materialID, string toolID)
        {
            MaterialModel product;
            if (RecipeDictionary.TryGetValue((materialID, toolID), out product))
            {
                return product;
            }
            else
            {
                return null;
            }
        }

        // Check if a recipe exists for a given material and tool
        public bool RecipeExists(string materialID, string toolID)
        {
            return RecipeDictionary.ContainsKey((materialID, toolID));
        }
    }
}
