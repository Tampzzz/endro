using _CalvinMonaSandehang.Database;
using _CalvinMonaSandehang.ItemSystem;
using _CalvinMonaSandehang.MaterialProcessing;
using _CalvinMonaSandehang.Tool;
using _CalvinMonaSandehang.UISystem;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace _CalvinMonaSandehang.Material.Processing
{

    public class HandleMaterialInteraction : MonoBehaviour
    {
        private MaterialModel material;
        private DraggableUIImage draggableUIImage;
        private HandleMaterialProcessing handleMaterialProcessing;

        public void Initialize(MaterialModel material, DraggableUIImage draggableUIimage, HandleMaterialProcessing processing) 
        {
            this.material = material;
            this.draggableUIImage = draggableUIimage;
            this.handleMaterialProcessing = processing;
        }
        
        private void OnTriggerStay2D(Collider2D other)
        {
            /*
            if (ToolType == GlobalDefine.ToolType.HeatSource)
            {
                if (other.CompareTag("Tool"))
                {
                    //material.Heat
                    
                }
            }
            */
        }

        private void OnTriggerEnter2D(Collider2D collision)
        {
            if(!draggableUIImage.IsActiveMaterial)
                return;

            if (collision.CompareTag("Material"))
            {
                HandleMaterialToMaterialInteraction(collision);
            } else if (collision.CompareTag("Tool"))
            {
                HandleMaterialToToolInteraction(collision);
            }
           
        }

        private void HandleMaterialToToolInteraction(Collider2D collision)
        {
            Debug.Log("Handle Material To Tool Interaction");
            ToolInfo toolInfo = collision.GetComponent <ToolInfo>();

            if (toolInfo != null)
            {
                PMaterial_SOSPToolRecipeDatabase recipeDatabase = PMaterial_SOSPToolRecipeDatabase.Instance;

                if (recipeDatabase != null)
                {
                    Debug.Log("Check PMaterial_SOSPToolRecipeDatabase");
                    MaterialModel productMaterial = recipeDatabase.GetProduct(material.ID, toolInfo.Tool.ID);
                    
                    if (productMaterial != null)
                    {
                        Debug.Log($"Product material = {productMaterial.Name}");
                        Vector2 mousePosition = draggableUIImage.MousePosition;
                        Transform parent = draggableUIImage.Parent;
                        handleMaterialProcessing.StartMaterialProcessing(parent, mousePosition, productMaterial);
                        Destroy(this.gameObject);
                    } else
                    {
                        Debug.Log("No product material found");
                    }
                }
            }
        }

        private void HandleMaterialToMaterialInteraction(Collider2D collision)
        {
            Debug.Log("Handle Material To Material Interaction");
            MaterialInfo otherMaterial = collision.GetComponent<MaterialInfo>();

            if (otherMaterial != null)
            {
                PNPRecipeDatabase recipeDatabase = PNPRecipeDatabase.Instance;

                if (recipeDatabase != null)
                {
                    //Debug.Log("Check Recipe Database");
                    var CheckRecipe1 = CheckRecipe(recipeDatabase, material, otherMaterial.Material);
                    var CheckRecipe2 = CheckRecipe(recipeDatabase, otherMaterial.Material, material);
                    // Check if a recipe exists for the combination of ItemSOs in both orders
                    bool recipeFound = CheckRecipe1.RecipeFound ||
                                       CheckRecipe2.RecipeFound;

                    //Debug.Log($"recipeFound = {recipeFound}");
                    MaterialModel productMaterial = null;
                    if (CheckRecipe1.RecipeFound)
                    {
                        //Debug.Log("Recipe Found");
                        productMaterial = CheckRecipe1.ProductMaterial;
                    }
                    else if (CheckRecipe2.RecipeFound)
                    {
                        //Debug.Log("Recipe Found");
                        productMaterial = CheckRecipe2.ProductMaterial;
                    }

                    if (recipeFound && productMaterial != null)
                    {
                        Vector2 mousePosition = draggableUIImage.MousePosition;
                        Transform parent = draggableUIImage.Parent;
                        handleMaterialProcessing.StartMaterialProcessing(parent, mousePosition, productMaterial);
                        Destroy(otherMaterial.gameObject);
                        Destroy(this.gameObject);

                    }
                }
            }
        }

        private (bool RecipeFound, MaterialModel ProductMaterial) CheckRecipe(PNPRecipeDatabase recipeDatabase, 
            MaterialModel material1, MaterialModel material2)
        {
            //Debug.Log($"material1 = {material1.Name}");
            //Debug.Log($"material2 = {material2.Name}");

            foreach (var recipe in recipeDatabase.PNPRecipe)
            {
                if (recipe.Key.Item1.ID == material1.ID && recipe.Key.Item2.ID == material2.ID)
                {
                    return (true, recipe.Value);
                }
            }
            return (false, null);
        }

        /*
        private Sprite GetProductSprite(PNPRecipeDatabase recipeDatabase, MaterialModel material1, MaterialModel material2)
        {
            foreach (var recipe in recipeDatabase.PNPRecipe)
            {
                if (recipe.Key.Item1 == material1 && recipe.Key.Item2 == material2)
                {
                    return recipe.Value.ItemSprite;
                }
            }
            return null;
        }
        */
    }
}

