using _CalvinMonaSandehang.ItemSystem;
using _CalvinMonaSandehang.Material;
using _CalvinMonaSandehang.UISystem;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace _CalvinMonaSandehang.MaterialProcessing
{
    public class HandleMaterialProcessing : MonoBehaviour
    {

        public void StartMaterialProcessing(Transform parent, Vector2 position, MaterialModel material)
        {
            MaterialProcessingManager.Instance.GetNewMaterial(parent, position, material);
        }
    }
}
