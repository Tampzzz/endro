using _CalvinMonaSandehang.ItemSystem;
using _CalvinMonaSandehang.Material;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace _CalvinMonaSandehang.MaterialProcessing
{
    public class MaterialProcessingManager : MonoBehaviour
    {
       public static MaterialProcessingManager Instance { get; private set; }

        private void Awake()
        {
            InitializeSingleton();
        }

        public GameObject GetNewMaterial(Transform parent, Vector2 position, MaterialModel material)
        {          
            // Instantiate the material object
            GameObject newMaterial = Instantiate(material.ItemPrefab, Vector3.zero, Quaternion.identity, parent);
            RectTransform newMaterialRect = newMaterial.GetComponent<RectTransform>();

            // Set anchored position relative to canvas
            Debug.Log($"position = {position}");
            newMaterialRect.anchoredPosition = position;

            return newMaterial;
        }


        private void InitializeSingleton()
        {
            if (Instance == null)
            {
                Instance = this;
            }
            else
            {
                Destroy(gameObject);
            }
        }

    }
}

