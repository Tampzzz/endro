using Sirenix.OdinInspector;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;
using static _CalvinMonaSandehang.GlobalDefine;

namespace _CalvinMonaSandehang.ItemSystem
{
    [CreateAssetMenu(menuName = "ItemSystem/Tool", fileName = "Tool_")]
    public class ToolSO : ItemSO
    {
        [FoldoutGroup("Tool Properties", expanded: true)]
        public ToolType ToolType;

        [FoldoutGroup("Tool Properties", expanded: true)]
        [ShowIf("IsHeatSource")]
        public float HeatPower;
        
        private bool IsHeatSource()
        {
            return ToolType == GlobalDefine.ToolType.HeatSource;
        }

        public ToolModel CreateToolModel()
        {
            return new ToolModel(this);
        }
    }
}

