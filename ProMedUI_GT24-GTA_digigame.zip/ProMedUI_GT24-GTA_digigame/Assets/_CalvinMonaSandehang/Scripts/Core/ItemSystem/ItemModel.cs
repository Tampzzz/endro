using Sirenix.OdinInspector;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static _CalvinMonaSandehang.GlobalDefine;

namespace _CalvinMonaSandehang.ItemSystem 
{
    [Serializable]
    public class ItemModel
    {
        public string ID;
        public string Name;
        public Sprite ItemSprite;
        public GameObject ItemPrefab;
        public int Quantity;
        public bool IsStackable;
        public int MaxStack;

        public ItemModel(ItemSO itemSO)
        {
            ID = itemSO.ID;
            Name = itemSO.Name;
            ItemSprite = itemSO.ItemSprite;
            ItemPrefab = itemSO.ItemPrefab;
            IsStackable = itemSO.IsStackable;
            MaxStack = itemSO.MaxStack;
            Quantity = 0; 
        }

        // Parameterless constructor
        public ItemModel()
        {
        }
    }
}

