using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static _CalvinMonaSandehang.GlobalDefine;

namespace _CalvinMonaSandehang.ItemSystem
{
    public class ToolModel : ItemModel
    {
        public ToolType ToolType;
        public float HeatPower;

        public ToolModel(ToolSO so)
        {
            // Material specific properties
            ToolType = so.ToolType;

            ID = so.ID;
            Name = so.Name;
            ToolType = so.ToolType;
            IsStackable = so.IsStackable;
            MaxStack = so.MaxStack;

            ItemSprite = so.ItemSprite;
            ItemPrefab = so.ItemPrefab;
            
            // Heat source
            HeatPower = so.HeatPower;
        }
    }
}

