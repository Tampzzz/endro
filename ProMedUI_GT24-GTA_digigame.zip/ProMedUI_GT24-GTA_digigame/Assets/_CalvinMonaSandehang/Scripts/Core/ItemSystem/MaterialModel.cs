using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static _CalvinMonaSandehang.GlobalDefine;

namespace _CalvinMonaSandehang.ItemSystem
{
    public class MaterialModel : ItemModel
    {
        public MaterialType MaterialType;
        public bool HasHeatEvolution;
        public List<MaterialSO> HeatEvolution;

        public MaterialModel(MaterialSO so)
        {
            // Material specific properties
            MaterialType = so.MaterialType;

            ID = so.ID;
            Name = so.Name;
            MaterialType = so.MaterialType;
            IsStackable = so.IsStackable;
            MaxStack = so.MaxStack;

            ItemSprite = so.ItemSprite;
            ItemPrefab = so.ItemPrefab;
            
            //Heat evolution
            //HasHeatEvolution = so.HasHeatEvolution;
            //if(HasHeatEvolution)
                //HeatEvolution = new List<MaterialSO>(so.HeatEvolution);
        }
    }
}

