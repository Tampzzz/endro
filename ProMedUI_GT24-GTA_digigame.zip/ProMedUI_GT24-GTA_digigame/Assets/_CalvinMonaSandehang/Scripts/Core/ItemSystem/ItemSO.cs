using Sirenix.OdinInspector;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static _CalvinMonaSandehang.GlobalDefine;

namespace _CalvinMonaSandehang.ItemSystem 
{
    [CreateAssetMenu(menuName = "ItemSystem/Item", fileName = "Item")]
    public class ItemSO : SerializedScriptableObject
    {
        [FoldoutGroup("Basic Properties", expanded: true)]
        [ReadOnly]
        [SerializeField]
        private string _id = string.Empty;
        [FoldoutGroup("Basic Properties")]
        [SerializeField]
        private string _name = string.Empty;
        
        [FoldoutGroup("Basic Properties")]
        [SerializeField]
        private Sprite _itemSprite = null;
        [FoldoutGroup("Basic Properties")]
        [SerializeField]
        private GameObject _itemPrefab = null;
        [FoldoutGroup("Basic Properties")]
        [SerializeField]
        private bool _isStackable = false;
        [FoldoutGroup("Basic Properties")]
        [SerializeField, ShowIf(nameof(_isStackable))]
        private int _maxStack = 0;

        public string ID { get { return _id; } }
        public string Name { get { return _name; } }
        public Sprite ItemSprite { get { return _itemSprite; } }
        public GameObject ItemPrefab { get { return _itemPrefab; } }
        public bool IsStackable { get { return _isStackable; } }
        public int MaxStack { get { return _maxStack; } }

        public ItemModel CreateModel()
        {
            return new ItemModel(this);
        }

        public void Use()
        {
            Debug.Log($"Item {_name} is used)");
        }

        [Button("Generate ID"), FoldoutGroup("Basic Properties")]
        private void GenerateIngredientID()
        {
            var now = System.DateTime.Now;
            var randomNumber = new System.Random().Next(100, 1000); // Generates a random number between 100 and 999.
            _id = now.ToString("yyMMddHHmmss") + randomNumber.ToString("D3"); // Concatenates the date-time string with the random number.
        }
    }
    
        
}

