using Sirenix.OdinInspector;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static _CalvinMonaSandehang.GlobalDefine;


namespace _CalvinMonaSandehang.ItemSystem
{
    [CreateAssetMenu(menuName = "ItemSystem/Material", fileName = "Material_")]
    public class MaterialSO : ItemSO
    {
        [FoldoutGroup("Material Properties", expanded: true)]
        public MaterialType MaterialType;
        [FoldoutGroup("Material Properties", expanded: true)]
        public bool HasHeatEvolution;
        [FoldoutGroup("Material Properties", expanded: true), ShowIf("HasHeatEvolution")]
        public List<MaterialSO> HeatEvolution;

        public MaterialModel CreateMaterialModel()
        {
            return new MaterialModel(this);
        }

    }

}
