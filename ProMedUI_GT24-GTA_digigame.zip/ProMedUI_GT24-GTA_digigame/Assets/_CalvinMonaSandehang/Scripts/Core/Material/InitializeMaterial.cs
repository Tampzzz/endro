using _CalvinMonaSandehang.Database;
using _CalvinMonaSandehang.ItemSystem;
using _CalvinMonaSandehang.Material.Processing;
using _CalvinMonaSandehang.MaterialProcessing;
using _CalvinMonaSandehang.UISystem;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using static _CalvinMonaSandehang.GlobalDefine;

namespace _CalvinMonaSandehang.Material
{
    [RequireComponent(typeof(DraggableUIImage))]
    [RequireComponent(typeof(MaterialInfo))]
    [RequireComponent(typeof(HandleMaterialInteraction))]
    [RequireComponent(typeof(HandleMaterialProcessing))]
    public class InitializeMaterial : MonoBehaviour
    {
        public MaterialSO MaterialSO;

        private Image image;
        private MaterialModel materialModel;

        private MaterialInfo materialInfo;
        private HandleMaterialInteraction handleMaterialInteraction;
        private HandleMaterialProcessing handleMaterialProcessing;
        private DraggableUIImage draggableUIImage;

        private void Awake()
        {
            InitializeComponents();
            InitializeMaterialIngredient();            
        }

        private void InitializeMaterialIngredient()
        {
            image.sprite = MaterialSO.ItemSprite;
            materialModel = MaterialSO.CreateMaterialModel();
            
            draggableUIImage = GetComponent<DraggableUIImage>();

            materialInfo = GetComponent<MaterialInfo>();
            materialInfo.Initialize(materialModel);

            handleMaterialProcessing = GetComponent<HandleMaterialProcessing>();

            handleMaterialInteraction = GetComponent<HandleMaterialInteraction>();
            handleMaterialInteraction.Initialize(materialModel, draggableUIImage, handleMaterialProcessing);
        }

        public void InitializeMaterialProduct(MaterialModel material) 
        {
            materialModel = material;
            image.sprite = material.ItemSprite;

            draggableUIImage = GetComponent<DraggableUIImage>();

            materialInfo = GetComponent<MaterialInfo>();
            materialInfo.Initialize(materialModel);

            handleMaterialProcessing = GetComponent<HandleMaterialProcessing>();

            handleMaterialInteraction = GetComponent<HandleMaterialInteraction>();
            handleMaterialInteraction.Initialize(materialModel, draggableUIImage, handleMaterialProcessing);

        }

        private void InitializeComponents()
        {
            image = GetComponent<Image>();
        }

        public MaterialModel GetMaterialModel() 
        {
            return materialModel;
        }

        private void OnValidate()
        {
            if (MaterialSO != null)
            {
                image = GetComponent<Image>();
                image.sprite = MaterialSO.ItemSprite;
            }
        }


    }
}

