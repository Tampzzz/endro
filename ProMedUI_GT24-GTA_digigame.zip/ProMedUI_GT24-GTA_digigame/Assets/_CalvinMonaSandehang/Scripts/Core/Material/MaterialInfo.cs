using _CalvinMonaSandehang.ItemSystem;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace _CalvinMonaSandehang.Material 
{
    public class MaterialInfo : MonoBehaviour
    {
        private MaterialModel material;
        public MaterialModel Material => material;
        public bool IsProcessable;
        public void Initialize(MaterialModel material)
        {
            this.material = material;

            if (material.MaterialType == GlobalDefine.MaterialType.Processable) 
                IsProcessable = true;
        }
    }
}

