using _CalvinMonaSandehang.ItemSystem;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace _CalvinMonaSandehang 
{
    public static class GlobalDefine
    {
        public enum MaterialType
        {
            NonProcessable,
            Processable,
            Product,
        }

        public enum ToolType
        {
            SingleOutputSinglePossibility,
            HeatSource  ,  
        }

        [Serializable]
        public class PNPMaterialRecipe
        {
            public MaterialSO Material1;
            public MaterialSO Material2;
            public MaterialSO Product;
        }

        [Serializable]
        public class PMaterialToolRecipe
        {
            public MaterialSO Material;
            public ToolSO Tool;
            public MaterialSO Product;
        }


    }    

}
