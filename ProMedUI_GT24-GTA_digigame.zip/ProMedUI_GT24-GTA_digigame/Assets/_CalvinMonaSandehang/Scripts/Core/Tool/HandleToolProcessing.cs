using _CalvinMonaSandehang.ItemSystem;
using _CalvinMonaSandehang.MaterialProcessing;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace _CalvinMonaSandehang.Tool
{
    public class HandleToolProcessing : MonoBehaviour
    {
        public void StartMaterialProcessing(Transform parent, Vector2 position, MaterialModel productMaterial)
        {
            MaterialProcessingManager.Instance.GetNewMaterial(parent, position, productMaterial);
        }        
    }
}

