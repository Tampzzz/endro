using _CalvinMonaSandehang.ItemSystem;
using _CalvinMonaSandehang.Tool.Processing;
using _CalvinMonaSandehang.UISystem;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace _CalvinMonaSandehang.Tool
{
    [RequireComponent(typeof(DraggableUIImage))]
    [RequireComponent(typeof(ToolInfo))]
    [RequireComponent(typeof(HandleToolInteraction))]
    [RequireComponent(typeof(HandleToolProcessing))]
    public class InitializeTool : MonoBehaviour
    {
        public ToolSO ToolSO;

        private Image image;
        private ToolModel toolModel;

        private ToolInfo toolInfo;
        private DraggableUIImage draggableUIImage;
        private HandleToolProcessing handleToolProcessing;
        private HandleToolInteraction handleToolInteraction;

        private void Awake()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            image = GetComponent<Image>();
            image.sprite = ToolSO.ItemSprite;
            toolModel = ToolSO.CreateToolModel();

            toolInfo = GetComponent<ToolInfo>();
            toolInfo.Initialize(toolModel);

            handleToolProcessing = GetComponent<HandleToolProcessing>();
            draggableUIImage = GetComponent<DraggableUIImage>();

            handleToolInteraction = GetComponent<HandleToolInteraction>();
            handleToolInteraction.Initialize(toolInfo, draggableUIImage, handleToolProcessing);    
        }

        private void OnValidate()
        {
            if (ToolSO != null)
            {
                image = GetComponent<Image>();
                image.sprite = ToolSO.ItemSprite;
            }
        }
    }
}

