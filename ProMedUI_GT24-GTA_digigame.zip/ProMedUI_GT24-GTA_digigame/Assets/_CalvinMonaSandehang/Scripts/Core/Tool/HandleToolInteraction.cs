using _CalvinMonaSandehang.Database;
using _CalvinMonaSandehang.ItemSystem;
using _CalvinMonaSandehang.Material;
using _CalvinMonaSandehang.UISystem;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace _CalvinMonaSandehang.Tool.Processing
{
    public class HandleToolInteraction : MonoBehaviour
    {
        private ToolModel tool;
        private GlobalDefine.ToolType toolType;
        private DraggableUIImage draggableUIImage;
        private HandleToolProcessing handleMaterialProcessing;

        public void Initialize(ToolInfo toolInfo, DraggableUIImage draggableUIimage, 
            HandleToolProcessing handleToolProcessing)
        {
            this.tool = toolInfo.Tool;
            this.draggableUIImage = draggableUIimage;
            this.handleMaterialProcessing = handleToolProcessing;
        }
        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (!draggableUIImage.IsActiveMaterial)
                return;

            if (collision.CompareTag("Material"))
            {
                HandleMaterialToMaterialInteraction(collision);
            }
        }

        

        private void HandleMaterialToMaterialInteraction(Collider2D collision)
        {
            Debug.Log("Handle Tool to Material Interaction");
            MaterialInfo materialInfo = collision.GetComponent<MaterialInfo>();

            if (materialInfo != null)
            {
                PMaterial_SOSPToolRecipeDatabase recipeDatabase = PMaterial_SOSPToolRecipeDatabase.Instance;

                if (recipeDatabase != null)
                {
                    Debug.Log("Check PMaterial_SOSPToolRecipeDatabase");
                    MaterialModel productMaterial = recipeDatabase.GetProduct(materialInfo.Material.ID, tool.ID);

                    if (productMaterial != null)
                    {
                        Debug.Log($"Product material = {productMaterial.Name}");
                        Vector2 position = materialInfo.GetComponent<RectTransform>().anchoredPosition;
                        Transform parent = draggableUIImage.Parent;
                        handleMaterialProcessing.StartMaterialProcessing(parent, position, productMaterial);
                        Destroy(materialInfo.gameObject);
                    }
                    else
                    {
                        Debug.Log("No product material found");
                    }
                }
            }
        }
    }

}

