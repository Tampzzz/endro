using _CalvinMonaSandehang.ItemSystem;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static _CalvinMonaSandehang.GlobalDefine;


namespace _CalvinMonaSandehang.Tool 
{
    public class ToolInfo : MonoBehaviour
    {
        private ToolModel tool;
        public ToolModel Tool => tool;
        public ToolType ToolType;

        public void Initialize(ToolModel tool)
        {
            this.tool = tool;
            ToolType = tool.ToolType;
        }
    }
}


