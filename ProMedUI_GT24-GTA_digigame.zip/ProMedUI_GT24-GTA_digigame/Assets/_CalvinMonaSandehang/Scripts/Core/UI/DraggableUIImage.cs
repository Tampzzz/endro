using UnityEngine;
using UnityEngine.EventSystems;

namespace _CalvinMonaSandehang.UISystem
{
    /// <summary>
    /// Allows dragging of a UI Image within a Canvas.
    /// </summary>
    [RequireComponent(typeof(RectTransform))]
    [RequireComponent(typeof(CanvasGroup))]
    public class DraggableUIImage : MonoBehaviour, IDragHandler, IEndDragHandler
    {
        private RectTransform rectTransform; // Reference to the RectTransform component of the UI Image.
        private Canvas canvas; // Reference to the Canvas component.
        private CanvasGroup canvasGroup; // Reference to the CanvasGroup component for controlling raycasts.
        private Vector2 mousePosition;
        public Vector2 MousePosition => mousePosition;

        private Transform parent;
        public Transform Parent => parent;

        public bool IsActiveMaterial;

        /// <summary>
        /// Initialize references to required components.
        /// </summary>
        private void Awake()
        {
            rectTransform = GetComponent<RectTransform>();
            canvas = GetComponentInParent<Canvas>();
            canvasGroup = GetComponent<CanvasGroup>();
            parent = transform.parent;
        }

        /// <summary>
        /// Called when the user starts dragging the UI Image.
        /// </summary>
        /// <param name="eventData">The pointer event data.</param>
        public void OnBeginDrag(PointerEventData eventData)
        {
            // Disable raycasts on the CanvasGroup to allow dragging without interaction.
            canvasGroup.blocksRaycasts = false;
            IsActiveMaterial = true;

            // Convert mouse position to canvas space
            RectTransformUtility.ScreenPointToLocalPointInRectangle(canvas.transform as RectTransform, 
                eventData.position, canvas.worldCamera, out mousePosition);
        }

        /// <summary>
        /// Called when the user is dragging the UI Image.
        /// </summary>
        /// <param name="eventData">The pointer event data.</param>
        public void OnDrag(PointerEventData eventData)
        {
            // Move the UI Image by the delta position of the pointer, adjusted for canvas scale.
            rectTransform.anchoredPosition += eventData.delta / canvas.scaleFactor;
            IsActiveMaterial = true;

            // Update mouse position
            RectTransformUtility.ScreenPointToLocalPointInRectangle(canvas.transform as RectTransform, eventData.position, canvas.worldCamera, out mousePosition);
            //Debug.Log($"{mousePosition}");
        }

        /// <summary>
        /// Called when the user stops dragging the UI Image.
        /// </summary>
        /// <param name="eventData">The pointer event data.</param>
        public void OnEndDrag(PointerEventData eventData)
        {
            // Re-enable raycasts on the CanvasGroup to allow interaction after dragging.
            canvasGroup.blocksRaycasts = true;
            IsActiveMaterial = false;
        }
    }
}
