﻿public class ES3XMLWriter
{
    // Not implemented
}
